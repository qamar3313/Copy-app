package com.example.copy

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class CopyService : AccessibilityService() {

    companion object {
        var instance: CopyService? = null
        private const val CHANNEL = "copy_trigger"
    }

    private var overlay: OverlayView? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        instance = this
        refreshNotification()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        closeOverlay()
        super.onDestroy()
    }

    /** Called from the Quick Settings tile or notification button. */
    fun activate() {
        closeOverlay()
        // Close the shade first so we read the app underneath, not the shade.
        performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        handler.postDelayed({ scanAndShow() }, 450)
    }

    private fun scanAndShow() {
        val root = rootInActiveWindow
        if (root == null) {
            toast("Nothing to read here")
            return
        }
        val items = mutableListOf<TextItem>()
        collect(root, items)
        if (items.isEmpty()) {
            toast("No text found")
            return
        }
        val view = OverlayView(
            this, items,
            manualOrder = Prefs.str(this, Prefs.ORDER, "manual") == "manual",
            selectAllDefault = Prefs.bool(this, Prefs.SELECT_ALL, false),
            onCopy = { text ->
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Copy", text))
            toast("Copied")
            closeOverlay()
        }, onClose = { closeOverlay() })
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(view, lp)
        overlay = view
    }

    private fun collect(node: AccessibilityNodeInfo, out: MutableList<TextItem>) {
        val text = (node.text ?: node.contentDescription)?.toString()?.trim()
        if (!text.isNullOrEmpty() && node.isVisibleToUser) {
            val r = Rect()
            node.getBoundsInScreen(r)
            if (r.width() > 0 && r.height() > 0) out.add(TextItem(text, r))
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collect(it, out) }
        }
    }

    private fun closeOverlay() {
        overlay?.let {
            runCatching { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) }
        }
        overlay = null
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    fun refreshNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!Prefs.bool(this, Prefs.NOTIF, true)) {
            nm.cancel(1)
            return
        }
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Copy trigger", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getBroadcast(
            this, 0, Intent(this, TriggerReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = Notification.Action.Builder(null, "Activate Copy", pi).build()
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setContentTitle("Copy")
            .setContentText("Tap to select text on screen")
            .setOngoing(true)
            .addAction(action)
            .build()
        nm.notify(1, n)
    }
}
