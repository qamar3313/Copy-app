package com.example.copy

import android.service.quicksettings.TileService

class CopyTile : TileService() {
    override fun onClick() {
        CopyService.instance?.activate()
    }
}
