package com.example.copy

import android.content.Context

object Prefs {
    const val NOTIF = "notification"
    const val SELECT_ALL = "select_all"
    const val ORDER = "order"
    const val DARK = "dark"

    private fun sp(c: Context) = c.getSharedPreferences("copy_prefs", Context.MODE_PRIVATE)
    fun bool(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun str(c: Context, k: String, d: String): String = sp(c).getString(k, d) ?: d
    fun setStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
}
