package com.example.copy

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.view.MotionEvent
import android.view.View

data class TextItem(val text: String, val bounds: Rect, var selected: Boolean = false)

class OverlayView(
    context: Context,
    private val items: List<TextItem>,
    private val onCopy: (String) -> Unit,
    private val onClose: () -> Unit
) : View(context) {

    private val dim = Paint().apply { color = Color.argb(70, 0, 0, 0) }
    private val zone = Paint().apply { color = Color.argb(90, 80, 170, 255) }
    private val picked = Paint().apply { color = Color.argb(170, 20, 90, 220) }
    private val stroke = Paint().apply {
        color = Color.argb(200, 20, 90, 220); style = Paint.Style.STROKE; strokeWidth = 3f
    }
    private val barPaint = Paint().apply { color = Color.rgb(30, 30, 30) }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 48f; textAlign = Paint.Align.CENTER
    }
    private val barH = 180f
    private val copyBtn = Rect()
    private val closeBtn = Rect()

    override fun onDraw(c: Canvas) {
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        for (i in items) {
            c.drawRect(i.bounds, if (i.selected) picked else zone)
            c.drawRect(i.bounds, stroke)
        }
        val top = height - barH.toInt()
        c.drawRect(0f, top.toFloat(), width.toFloat(), height.toFloat(), barPaint)
        closeBtn.set(0, top, width / 2, height)
        copyBtn.set(width / 2, top, width, height)
        val y = top + barH / 2 + 16f
        c.drawText("Close", closeBtn.exactCenterX(), y, label)
        val n = items.count { it.selected }
        c.drawText(if (n > 0) "Copy ($n)" else "Copy", copyBtn.exactCenterX(), y, label)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_UP) return true
        val x = e.x.toInt(); val y = e.y.toInt()
        when {
            closeBtn.contains(x, y) -> onClose()
            copyBtn.contains(x, y) -> {
                val text = items.filter { it.selected }.joinToString("\n") { it.text }
                if (text.isNotEmpty()) onCopy(text)
            }
            else -> {
                // Smallest box under the finger wins (inner text over its container)
                items.filter { it.bounds.contains(x, y) }
                    .minByOrNull { it.bounds.width() * it.bounds.height() }
                    ?.let { it.selected = !it.selected; invalidate() }
            }
        }
        return true
    }
}
