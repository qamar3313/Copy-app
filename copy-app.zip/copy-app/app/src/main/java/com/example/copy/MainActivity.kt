package com.example.copy

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dark() = Prefs.bool(this, Prefs.DARK, false)
    private fun bg() = if (dark()) Color.rgb(18, 18, 18) else Color.WHITE
    private fun fg() = if (dark()) Color.WHITE else Color.BLACK
    private fun sub() = if (dark()) Color.rgb(170, 170, 170) else Color.rgb(100, 100, 100)
    private val accent = Color.rgb(30, 100, 230)

    private fun isServiceEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.contains("$packageName/")
    }

    private fun build() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg())
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(32), dp(20), dp(40))
        scroll.addView(col)
        setContentView(scroll)

        col.addView(text("Copy", 30f, fg(), bold = true))

        val enabled = isServiceEnabled()
        col.addView(row(
            "Copy service",
            if (enabled) "On. Ready to use." else "Off. Tap to turn on in Accessibility settings."
        ) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })

        col.addView(section("Trigger"))
        col.addView(switchRow(
            "Notification button",
            "Show an Activate button in your notifications",
            Prefs.NOTIF, true
        ) { CopyService.instance?.refreshNotification() })
        col.addView(row(
            "Quick Settings tile",
            "Add the Copy tile from the edit menu of your Quick Settings"
        ) {})

        col.addView(section("Selection"))
        col.addView(switchRow(
            "Select all text by default",
            "Every text block starts selected when Copy opens",
            Prefs.SELECT_ALL, false
        ) {})
        val orderNow = Prefs.str(this, Prefs.ORDER, "manual")
        col.addView(row(
            "Selection order",
            if (orderNow == "manual") "Manual: in the order you tap" else "By position: top to bottom"
        ) {
            val labels = arrayOf("Manual: in the order you tap", "By position: top to bottom")
            AlertDialog.Builder(this)
                .setTitle("Selection order")
                .setItems(labels) { _, i ->
                    Prefs.setStr(this, Prefs.ORDER, if (i == 0) "manual" else "position")
                    build()
                }.show()
        })

        col.addView(section("Reliability"))
        col.addView(row(
            "Keep Copy running",
            "Open battery settings and exclude Copy from optimisation"
        ) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) })

        col.addView(section("Appearance"))
        col.addView(switchRow("Dark theme", "Use a dark background in this screen", Prefs.DARK, false) { build() })

        col.addView(section("About"))
        col.addView(row("Version", "0.2") {})
        col.addView(row("Privacy", "Text is read and processed only on your device") {})
    }

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun section(t: String): TextView =
        text(t, 14f, accent, bold = true).apply { setPadding(0, dp(28), 0, dp(4)) }

    private fun textColumn(title: String, subtitle: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.addView(text(title, 17f, fg()))
        c.addView(text(subtitle, 14f, sub()).apply { setPadding(0, dp(2), 0, 0) })
        return c
    }

    private fun row(title: String, subtitle: String, onClick: () -> Unit): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(0, dp(12), 0, dp(12))
        r.addView(textColumn(title, subtitle))
        r.setOnClickListener { onClick() }
        return r
    }

    private fun switchRow(
        title: String, subtitle: String, key: String, default: Boolean, onChange: () -> Unit
    ): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, dp(12), 0, dp(12))
        val col = textColumn(title, subtitle)
        r.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this)
        sw.isChecked = Prefs.bool(this, key, default)
        sw.setOnCheckedChangeListener { _, checked ->
            Prefs.setBool(this, key, checked)
            onChange()
        }
        r.addView(sw)
        r.setOnClickListener { sw.toggle() }
        return r
    }
}
