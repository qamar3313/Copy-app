# Copy (MVP)
Open in Android Studio (Hedgehog or newer) -> Run on a device (Android 8+).
1. Open the app -> "Open accessibility settings" -> enable Copy.
2. Add the Copy tile to Quick Settings (or use the notification button).
3. Open any app, trigger Copy, tap text boxes, press Copy.

Next steps: Scanner/OCR mode (takeScreenshot + ML Kit), Scroll mode, Harvest mode, Plus billing.
Before Play Store: pick a distinctive name, fill the accessibility declaration form, add a privacy policy.
